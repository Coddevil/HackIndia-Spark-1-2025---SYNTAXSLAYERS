import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useChat } from '../context/ChatContext';
import ChatBubble from '../components/ChatBubble';
import ChatInput from '../components/ChatInput';
import Avatar from '../components/Avatar';
import VideoCall from '../components/VideoCall';
import VoiceCall from '../components/VoiceCall';
import { LogOut, Trash2, Settings, Moon, Sun } from 'lucide-react';

const Chat: React.FC = () => {
  const { currentUser, logout } = useAuth();
  const { messages, clearChat, isTyping } = useChat();
  const [showVideoCall, setShowVideoCall] = useState(false);
  const [showVoiceCall, setShowVoiceCall] = useState(false);
  const [darkMode, setDarkMode] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();
  
  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);
  
  // Redirect if not logged in
  useEffect(() => {
    if (!currentUser) {
      navigate('/');
    }
  }, [currentUser, navigate]);
  
  // Handle logout
  const handleLogout = () => {
    logout();
    navigate('/');
  };
  
  // Get the last AI message emotion for avatar
  const getLastAIEmotion = () => {
    const aiMessages = messages.filter(msg => msg.sender === 'ai');
    if (aiMessages.length > 0) {
      return aiMessages[aiMessages.length - 1].emotion || 'neutral';
    }
    return 'neutral';
  };
  
  return (
    <div className={`min-h-screen flex flex-col ${darkMode ? 'bg-gray-900 text-white' : 'bg-gray-100'}`}>
      {/* Header */}
      <header className={`p-4 ${darkMode ? 'bg-gray-800' : 'bg-white'} shadow-sm flex items-center justify-between`}>
        <div className="flex items-center">
          <Avatar emotion={getLastAIEmotion()} size="sm" />
          <h1 className="ml-3 font-semibold">MindMate AI</h1>
        </div>
        
        <div className="flex items-center space-x-2">
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => setDarkMode(!darkMode)}
            className={`p-2 rounded-full ${darkMode ? 'bg-gray-700 text-yellow-400' : 'bg-gray-200 text-gray-700'}`}
            aria-label={darkMode ? "Switch to light mode" : "Switch to dark mode"}
          >
            {darkMode ? <Sun size={18} /> : <Moon size={18} />}
          </motion.button>
          
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={clearChat}
            className={`p-2 rounded-full ${darkMode ? 'bg-gray-700 text-gray-300' : 'bg-gray-200 text-gray-700'}`}
            aria-label="Clear chat"
          >
            <Trash2 size={18} />
          </motion.button>
          
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            className={`p-2 rounded-full ${darkMode ? 'bg-gray-700 text-gray-300' : 'bg-gray-200 text-gray-700'}`}
            aria-label="Settings"
          >
            <Settings size={18} />
          </motion.button>
          
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={handleLogout}
            className={`p-2 rounded-full ${darkMode ? 'bg-gray-700 text-gray-300' : 'bg-gray-200 text-gray-700'}`}
            aria-label="Logout"
          >
            <LogOut size={18} />
          </motion.button>
        </div>
      </header>
      
      {/* Chat Messages */}
      <div className="flex-1 overflow-y-auto p-4">
        <div className="max-w-3xl mx-auto">
          {messages.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center p-8">
              <Avatar emotion="encouraging" size="md" />
              <h2 className={`mt-4 text-xl font-semibold ${darkMode ? 'text-white' : 'text-gray-800'}`}>
                Welcome to MindMate AI
              </h2>
              <p className={`mt-2 ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
                Your personal mental health companion. Start a conversation to get support and guidance.
              </p>
            </div>
          ) : (
            <AnimatePresence>
              {messages.map(message => (
                <ChatBubble key={message.id} message={message} />
              ))}
            </AnimatePresence>
          )}
          
          {/* Typing indicator */}
          {isTyping && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              className={`max-w-[80%] mr-auto mb-4 p-3 rounded-tr-xl rounded-br-xl rounded-bl-xl ${
                darkMode ? 'bg-blue-900 text-blue-100' : 'bg-blue-100 text-blue-900'
              }`}
            >
              <div className="flex space-x-2">
                <motion.div
                  className={`w-2 h-2 rounded-full ${darkMode ? 'bg-blue-300' : 'bg-blue-500'}`}
                  animate={{ y: [0, -6, 0] }}
                  transition={{ repeat: Infinity, duration: 0.8, delay: 0 }}
                />
                <motion.div
                  className={`w-2 h-2 rounded-full ${darkMode ? 'bg-blue-300' : 'bg-blue-500'}`}
                  animate={{ y: [0, -6, 0] }}
                  transition={{ repeat: Infinity, duration: 0.8, delay: 0.2 }}
                />
                <motion.div
                  className={`w-2 h-2 rounded-full ${darkMode ? 'bg-blue-300' : 'bg-blue-500'}`}
                  animate={{ y: [0, -6, 0] }}
                  transition={{ repeat: Infinity, duration: 0.8, delay: 0.4 }}
                />
              </div>
            </motion.div>
          )}
          
          <div ref={messagesEndRef} />
        </div>
      </div>
      
      {/* Chat Input */}
      <ChatInput 
        onStartVoiceCall={() => setShowVoiceCall(true)}
        onStartVideoCall={() => setShowVideoCall(true)}
      />
      
      {/* Video Call Modal */}
      <AnimatePresence>
        {showVideoCall && (
          <VideoCall onClose={() => setShowVideoCall(false)} />
        )}
      </AnimatePresence>
      
      {/* Voice Call Modal */}
      <AnimatePresence>
        {showVoiceCall && (
          <VoiceCall onClose={() => setShowVoiceCall(false)} />
        )}
      </AnimatePresence>
    </div>
  );
};

export default Chat;