import React, { createContext, useState, useContext, useEffect } from 'react';
import { Message, ChatHistory } from '../types';
import { useAuth } from './AuthContext';
import { v4 as uuidv4 } from '../utils/uuid';

interface ChatContextType {
  messages: Message[];
  addMessage: (text: string, sender: 'user' | 'ai', emotion?: Message['emotion']) => void;
  clearChat: () => void;
  deleteMessage: (id: string) => void;
  isTyping: boolean;
}

const ChatContext = createContext<ChatContextType>({
  messages: [],
  addMessage: () => {},
  clearChat: () => {},
  deleteMessage: () => {},
  isTyping: false,
});

export const useChat = () => useContext(ChatContext);

export const ChatProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isTyping, setIsTyping] = useState(false);
  const { currentUser } = useAuth();

  // Load chat history from localStorage when user changes
  useEffect(() => {
    if (currentUser) {
      const savedChat = localStorage.getItem(`mindmate_chat_${currentUser.id}`);
      if (savedChat) {
        setMessages(JSON.parse(savedChat));
      } else {
        // Welcome message for new users
        addMessage(
          `Hello ${currentUser.name}! I'm MindMate AI, your personal mental health companion. How are you feeling today?`,
          'ai',
          'encouraging'
        );
      }
    } else {
      setMessages([]);
    }
  }, [currentUser]);

  // Save messages to localStorage whenever they change
  useEffect(() => {
    if (currentUser && messages.length > 0) {
      localStorage.setItem(`mindmate_chat_${currentUser.id}`, JSON.stringify(messages));
    }
  }, [messages, currentUser]);

  const addMessage = (text: string, sender: 'user' | 'ai', emotion: Message['emotion'] = 'neutral') => {
    const newMessage: Message = {
      id: uuidv4(),
      sender,
      text,
      timestamp: Date.now(),
      emotion,
    };

    if (sender === 'user') {
      setMessages(prev => [...prev, newMessage]);
      
      // Simulate AI thinking
      setIsTyping(true);
      
      // Process user input and generate AI response
      setTimeout(() => {
        const aiResponse = generateAIResponse(text, currentUser);
        setIsTyping(false);
        
        setMessages(prev => [
          ...prev,
          {
            id: uuidv4(),
            sender: 'ai',
            text: aiResponse.text,
            timestamp: Date.now(),
            emotion: aiResponse.emotion,
          },
        ]);
      }, 1500 + Math.random() * 1000); // Random delay between 1.5-2.5 seconds
    } else {
      setMessages(prev => [...prev, newMessage]);
    }
  };

  const clearChat = () => {
    if (currentUser) {
      localStorage.removeItem(`mindmate_chat_${currentUser.id}`);
    }
    setMessages([]);
    
    // Add welcome message after clearing
    if (currentUser) {
      addMessage(
        `Chat history cleared. How else can I help you today, ${currentUser.name}?`,
        'ai',
        'encouraging'
      );
    }
  };

  const deleteMessage = (id: string) => {
    setMessages(prev => prev.filter(message => message.id !== id));
  };

  return (
    <ChatContext.Provider value={{ messages, addMessage, clearChat, deleteMessage, isTyping }}>
      {children}
    </ChatContext.Provider>
  );
};

// Enhanced AI response generator
function generateAIResponse(userInput: string, user: any): { text: string; emotion: Message['emotion'] } {
  const input = userInput.toLowerCase().trim();
  
  // Check for nonsensical input - improved pattern matching
  if (!/^[a-z0-9\s.,!?'"-]+$/i.test(input) || input.length < 2 || /[^\w\s.,!?'"-]/.test(input)) {
    return {
      text: "I can't get you. Can you please try again with clearer wording?",
      emotion: 'concerned'
    };
  }
  
  // Detect greeting
  if (input.match(/^(hi|hello|hey|greetings).*/i)) {
    return {
      text: `Hello ${user?.name || 'there'}! How are you feeling today?`,
      emotion: 'happy'
    };
  }
  
  // Detect negative emotions
  if (input.match(/(sad|depressed|unhappy|miserable|lonely|anxious|worried|stressed)/i)) {
    return {
      text: `I'm sorry to hear you're feeling that way. Remember that it's okay to have these feelings, and they will pass. Would you like to try a quick breathing exercise together?`,
      emotion: 'concerned'
    };
  }
  
  // Detect positive emotions
  if (input.match(/(happy|good|great|excellent|amazing|wonderful|fantastic|excited)/i)) {
    return {
      text: `That's wonderful to hear! I'm so glad you're feeling positive. What's contributing to your good mood today?`,
      emotion: 'happy'
    };
  }
  
  // Detect questions about the AI
  if (input.match(/who are you|what are you|are you real|are you human/i)) {
    return {
      text: `I'm MindMate AI, your personal mental health companion. While I'm not human, I'm designed to provide supportive conversations and be here for you whenever you need someone to talk to.`,
      emotion: 'neutral'
    };
  }
  
  // Default responses for other inputs
  const defaultResponses = [
    `I appreciate you sharing that with me. How does that make you feel?`,
    `Thank you for telling me. Would you like to explore that further?`,
    `I'm here to listen. Would you like to tell me more about that?`,
    `That's interesting. How long have you been feeling this way?`,
    `I understand. What do you think might help in this situation?`
  ];
  
  return {
    text: defaultResponses[Math.floor(Math.random() * defaultResponses.length)],
    emotion: 'neutral'
  };
}