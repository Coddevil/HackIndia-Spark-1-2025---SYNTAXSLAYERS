import React from 'react';
import { motion } from 'framer-motion';
import { Message } from '../types';
import { Trash2 } from 'lucide-react';
import { useChat } from '../context/ChatContext';

interface ChatBubbleProps {
  message: Message;
}

const ChatBubble: React.FC<ChatBubbleProps> = ({ message }) => {
  const { deleteMessage } = useChat();
  const isAI = message.sender === 'ai';
  
  // Format timestamp
  const formattedTime = new Date(message.timestamp).toLocaleTimeString([], { 
    hour: '2-digit', 
    minute: '2-digit' 
  });

  // Animation variants
  const variants = {
    hidden: { 
      opacity: 0, 
      y: 20, 
      scale: 0.8 
    },
    visible: { 
      opacity: 1, 
      y: 0, 
      scale: 1,
      transition: { 
        type: 'spring', 
        stiffness: 500, 
        damping: 30 
      } 
    },
    exit: { 
      opacity: 0, 
      scale: 0.8, 
      transition: { 
        duration: 0.2 
      } 
    }
  };

  // Determine bubble style based on sender
  const bubbleStyle = isAI 
    ? "bg-blue-100 text-blue-900 rounded-tr-xl rounded-br-xl rounded-bl-xl" 
    : "bg-indigo-600 text-white rounded-tl-xl rounded-tr-xl rounded-bl-xl ml-auto";

  return (
    <motion.div
      className={`max-w-[80%] ${isAI ? 'mr-auto' : 'ml-auto'} mb-4 relative group`}
      initial="hidden"
      animate="visible"
      exit="exit"
      variants={variants}
      layout
    >
      <div className={`p-3 ${bubbleStyle} shadow-sm`}>
        <p className="text-sm md:text-base">{message.text}</p>
        <span className="text-xs opacity-70 block mt-1">{formattedTime}</span>
      </div>
      
      {/* Delete button */}
      <motion.button
        className="absolute -right-8 top-0 opacity-0 group-hover:opacity-100 transition-opacity"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={() => deleteMessage(message.id)}
        aria-label="Delete message"
      >
        <Trash2 size={16} className="text-gray-500 hover:text-red-500" />
      </motion.button>
    </motion.div>
  );
};

export default ChatBubble;