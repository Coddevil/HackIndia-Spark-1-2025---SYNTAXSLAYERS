import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { X, Mic, MicOff, Video, VideoOff } from 'lucide-react';
import Avatar from './Avatar';
import { useAuth } from '../context/AuthContext';

interface VideoCallProps {
  onClose: () => void;
}

const VideoCall: React.FC<VideoCallProps> = ({ onClose }) => {
  const [isMuted, setIsMuted] = useState(false);
  const [isCameraOff, setIsCameraOff] = useState(false);
  const [currentEmotion, setCurrentEmotion] = useState<'neutral' | 'happy' | 'sad' | 'concerned' | 'encouraging'>('neutral');
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [currentSpeech, setCurrentSpeech] = useState('');
  const { currentUser } = useAuth();
  const audioRef = useRef<HTMLAudioElement | null>(null);
  
  // Determine avatar gender based on user gender (opposite)
  const avatarGender = currentUser?.gender === 'female' ? 'male' : 'female';
  
  // Simulate AI speaking and changing emotions
  useEffect(() => {
    const emotions: Array<'neutral' | 'happy' | 'sad' | 'concerned' | 'encouraging'> = [
      'neutral', 'happy', 'concerned', 'encouraging'
    ];
    
    const greetings = [
      `Hello ${currentUser?.name || 'there'}! It's great to see you today.`,
      `Hi there! I'm glad we can connect face to face.`,
      `Welcome to our video call! How can I help you today?`
    ];
    
    const randomGreeting = greetings[Math.floor(Math.random() * greetings.length)];
    
    // Initial greeting
    setTimeout(() => {
      setIsSpeaking(true);
      setCurrentEmotion('happy');
      setCurrentSpeech(randomGreeting);
      
      // Simulate speech with audio
      speakText(randomGreeting, avatarGender);
      
      // Stop speaking after speech duration
      setTimeout(() => {
        setIsSpeaking(false);
        setCurrentSpeech('');
      }, 3000);
    }, 1000);
    
    // Change emotions periodically
    const emotionInterval = setInterval(() => {
      const randomEmotion = emotions[Math.floor(Math.random() * emotions.length)];
      setCurrentEmotion(randomEmotion);
    }, 8000);
    
    // Simulate speaking periodically
    const speakingInterval = setInterval(() => {
      if (!isMuted) {
        const phrases = [
          "How are you feeling today?",
          "Is there anything specific you'd like to talk about?",
          "I'm here to listen and support you.",
          "Remember that your feelings are valid.",
          "Would you like to try a mindfulness exercise together?"
        ];
        
        const randomPhrase = phrases[Math.floor(Math.random() * phrases.length)];
        setIsSpeaking(true);
        setCurrentSpeech(randomPhrase);
        
        // Simulate speech with audio
        speakText(randomPhrase, avatarGender);
        
        setTimeout(() => {
          setIsSpeaking(false);
          setCurrentSpeech('');
        }, 2000 + Math.random() * 3000);
      }
    }, 7000);
    
    return () => {
      clearInterval(emotionInterval);
      clearInterval(speakingInterval);
    };
  }, [currentUser, isMuted, avatarGender]);

  // Function to simulate speech with different voices based on gender
  const speakText = (text: string, gender: string) => {
    if ('speechSynthesis' in window) {
      // Create speech synthesis
      const utterance = new SpeechSynthesisUtterance(text);
      
      // Get available voices
      const voices = window.speechSynthesis.getVoices();
      
      // Set voice based on gender
      if (voices.length > 0) {
        // Find appropriate voice based on gender
        const voiceOptions = voices.filter(voice => 
          gender === 'female' ? voice.name.includes('female') || voice.name.includes('woman') : 
                               voice.name.includes('male') || voice.name.includes('man')
        );
        
        // Use filtered voice or default
        utterance.voice = voiceOptions.length > 0 ? voiceOptions[0] : voices[0];
        
        // Adjust pitch based on gender
        utterance.pitch = gender === 'female' ? 1.2 : 0.9;
        utterance.rate = 1.0;
        
        // Speak the text
        window.speechSynthesis.speak(utterance);
      }
    }
  };

  return (
    <motion.div
      className="fixed inset-0 bg-black z-50 flex flex-col"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <div className="flex justify-between items-center p-4 bg-gray-900">
        <h2 className="text-white text-lg font-semibold">
          Video Call with MindMate AI
        </h2>
        <button 
          onClick={onClose}
          className="text-white hover:text-red-500"
          aria-label="End call"
        >
          <X size={24} />
        </button>
      </div>
      
      <div className="flex-1 flex items-center justify-center bg-gradient-to-b from-gray-900 to-gray-800">
        <div className="relative w-full max-w-2xl aspect-video bg-gray-700 rounded-lg overflow-hidden shadow-xl">
          {/* AI Video Feed */}
          <div className="absolute inset-0 flex items-center justify-center">
            <Avatar emotion={currentEmotion} speaking={isSpeaking} size="lg" />
          </div>
          
          {/* Speech bubble when AI is speaking */}
          {isSpeaking && currentSpeech && (
            <motion.div 
              className="absolute bottom-4 left-4 right-4 bg-white bg-opacity-90 p-3 rounded-xl text-gray-800"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
            >
              <p className="text-center">{currentSpeech}</p>
            </motion.div>
          )}
          
          {/* User Video Feed (small overlay) */}
          <div className="absolute bottom-4 right-4 w-32 h-32 bg-gray-800 rounded-lg overflow-hidden border-2 border-white shadow-lg">
            <div className="w-full h-full flex items-center justify-center text-white">
              {isCameraOff ? (
                <p className="text-xs">Camera Off</p>
              ) : (
                <div className="w-full h-full bg-gray-600 flex items-center justify-center">
                  <p className="text-xs">{currentUser?.name || 'You'}</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      
      <div className="bg-gray-900 p-4 flex justify-center space-x-4">
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={() => setIsMuted(!isMuted)}
          className={`p-3 rounded-full ${isMuted ? 'bg-red-500' : 'bg-gray-700'}`}
          aria-label={isMuted ? "Unmute" : "Mute"}
        >
          {isMuted ? <MicOff size={24} className="text-white" /> : <Mic size={24} className="text-white" />}
        </motion.button>
        
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={() => setIsCameraOff(!isCameraOff)}
          className={`p-3 rounded-full ${isCameraOff ? 'bg-red-500' : 'bg-gray-700'}`}
          aria-label={isCameraOff ? "Turn camera on" : "Turn camera off"}
        >
          {isCameraOff ? <VideoOff size={24} className="text-white" /> : <Video size={24} className="text-white" />}
        </motion.button>
        
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={onClose}
          className="p-3 rounded-full bg-red-600"
          aria-label="End call"
        >
          <X size={24} className="text-white" />
        </motion.button>
      </div>
      
      {/* Hidden audio element for potential audio playback */}
      <audio ref={audioRef} className="hidden" />
    </motion.div>
  );
};

export default VideoCall;