import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { X, Mic, MicOff } from 'lucide-react';
import Avatar from './Avatar';
import { useAuth } from '../context/AuthContext';

interface VoiceCallProps {
  onClose: () => void;
}

const VoiceCall: React.FC<VoiceCallProps> = ({ onClose }) => {
  const [isMuted, setIsMuted] = useState(false);
  const [currentEmotion, setCurrentEmotion] = useState<'neutral' | 'happy' | 'sad' | 'concerned' | 'encouraging'>('neutral');
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [callDuration, setCallDuration] = useState(0);
  const [currentSpeech, setCurrentSpeech] = useState('');
  const { currentUser } = useAuth();
  const audioRef = useRef<HTMLAudioElement | null>(null);
  
  // Determine avatar gender based on user gender (opposite)
  const avatarGender = currentUser?.gender === 'female' ? 'male' : 'female';
  
  // Simulate AI speaking and changing emotions
  useEffect(() => {
    const emotions: Array<'neutral' | 'happy' | 'sad' | 'concerned' | 'encouraging'> = [
      'neutral', 'happy', 'concerned', 'encouraging'
    ];
    
    const greetings = [
      `Hello ${currentUser?.name || 'there'}! It's great to talk with you today.`,
      `Hi there! I'm glad we can connect.`,
      `Welcome to our call! How can I help you today?`
    ];
    
    const randomGreeting = greetings[Math.floor(Math.random() * greetings.length)];
    
    // Initial greeting
    setTimeout(() => {
      setIsSpeaking(true);
      setCurrentEmotion('happy');
      setCurrentSpeech(randomGreeting);
      
      // Simulate speech with audio
      speakText(randomGreeting, avatarGender);
      
      // Stop speaking after speech duration
      setTimeout(() => {
        setIsSpeaking(false);
        setCurrentSpeech('');
      }, 3000);
    }, 1000);
    
    // Change emotions periodically
    const emotionInterval = setInterval(() => {
      const randomEmotion = emotions[Math.floor(Math.random() * emotions.length)];
      setCurrentEmotion(randomEmotion);
    }, 8000);
    
    // Simulate speaking periodically
    const speakingInterval = setInterval(() => {
      if (!isMuted) {
        const phrases = [
          "How are you feeling today?",
          "Is there anything specific you'd like to talk about?",
          "I'm here to listen and support you.",
          "Remember that your feelings are valid.",
          "Would you like to try a mindfulness exercise together?"
        ];
        
        const randomPhrase = phrases[Math.floor(Math.random() * phrases.length)];
        setIsSpeaking(true);
        setCurrentSpeech(randomPhrase);
        
        // Simulate speech with audio
        speakText(randomPhrase, avatarGender);
        
        setTimeout(() => {
          setIsSpeaking(false);
          setCurrentSpeech('');
        }, 2000 + Math.random() * 3000);
      }
    }, 7000);
    
    // Call duration timer
    const durationTimer = setInterval(() => {
      setCallDuration(prev => prev + 1);
    }, 1000);
    
    return () => {
      clearInterval(emotionInterval);
      clearInterval(speakingInterval);
      clearInterval(durationTimer);
      
      // Cancel any ongoing speech when component unmounts
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, [currentUser, isMuted, avatarGender]);
  
  // Function to simulate speech with different voices based on gender
  const speakText = (text: string, gender: string) => {
    if ('speechSynthesis' in window) {
      // Create speech synthesis
      const utterance = new SpeechSynthesisUtterance(text);
      
      // Get available voices
      const voices = window.speechSynthesis.getVoices();
      
      // Set voice based on gender
      if (voices.length > 0) {
        // Find appropriate voice based on gender
        const voiceOptions = voices.filter(voice => 
          gender === 'female' ? voice.name.includes('female') || voice.name.includes('woman') : 
                               voice.name.includes('male') || voice.name.includes('man')
        );
        
        // Use filtered voice or default
        utterance.voice = voiceOptions.length > 0 ? voiceOptions[0] : voices[0];
        
        // Adjust pitch based on gender
        utterance.pitch = gender === 'female' ? 1.2 : 0.9;
        utterance.rate = 1.0;
        
        // Speak the text
        window.speechSynthesis.speak(utterance);
      }
    }
  };
  
  // Format call duration
  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <motion.div
      className="fixed inset-0 bg-gradient-to-b from-blue-900 to-indigo-900 z-50 flex flex-col"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <div className="flex justify-between items-center p-4">
        <h2 className="text-white text-lg font-semibold">
          Voice Call with MindMate AI
        </h2>
        <div className="text-white bg-black bg-opacity-30 px-3 py-1 rounded-full">
          {formatDuration(callDuration)}
        </div>
        <button 
          onClick={onClose}
          className="text-white hover:text-red-500"
          aria-label="End call"
        >
          <X size={24} />
        </button>
      </div>
      
      <div className="flex-1 flex items-center justify-center">
        <motion.div 
          className="flex flex-col items-center"
          animate={{ scale: isSpeaking ? [1, 1.05, 1] : 1 }}
          transition={{ repeat: isSpeaking ? Infinity : 0, duration: 1 }}
        >
          <div className="mb-8 relative">
            <motion.div
              className="absolute -inset-4 rounded-full"
              animate={{
                boxShadow: isSpeaking 
                  ? ['0 0 0 0 rgba(255,255,255,0)', '0 0 0 20px rgba(255,255,255,0.2)', '0 0 0 0 rgba(255,255,255,0)'] 
                  : '0 0 0 0 rgba(255,255,255,0)'
              }}
              transition={{ repeat: isSpeaking ? Infinity : 0, duration: 1.5 }}
            />
            <Avatar emotion={currentEmotion} speaking={isSpeaking} size="lg" />
          </div>
          
          <h3 className="text-white text-2xl font-semibold mb-2">MindMate AI</h3>
          <p className="text-blue-200">
            {isSpeaking ? 'Speaking...' : 'Listening...'}
          </p>
          
          {/* Speech bubble when AI is speaking */}
          {isSpeaking && currentSpeech && (
            <motion.div 
              className="mt-4 bg-white bg-opacity-20 p-3 rounded-xl text-white max-w-md"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
            >
              <p className="text-center">{currentSpeech}</p>
            </motion.div>
          )}
        </motion.div>
      </div>
      
      <div className="p-8 flex justify-center space-x-8">
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={() => setIsMuted(!isMuted)}
          className={`p-4 rounded-full ${isMuted ? 'bg-red-500' : 'bg-white bg-opacity-20'}`}
          aria-label={isMuted ? "Unmute" : "Mute"}
        >
          {isMuted ? <MicOff size={28} className="text-white" /> : <Mic size={28} className="text-white" />}
        </motion.button>
        
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={onClose}
          className="p-4 rounded-full bg-red-600"
          aria-label="End call"
        >
          <X size={28} className="text-white" />
        </motion.button>
      </div>
      
      {/* Hidden audio element for potential audio playback */}
      <audio ref={audioRef} className="hidden" />
    </motion.div>
  );
};

export default VoiceCall;