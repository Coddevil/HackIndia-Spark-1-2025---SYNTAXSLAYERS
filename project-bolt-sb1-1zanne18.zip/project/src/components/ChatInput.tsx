import React, { useState, useRef, useEffect } from 'react';
import { Send, Mic, MicOff, Video, Phone } from 'lucide-react';
import { motion } from 'framer-motion';
import { useChat } from '../context/ChatContext';

interface ChatInputProps {
  onStartVoiceCall: () => void;
  onStartVideoCall: () => void;
}

const ChatInput: React.FC<ChatInputProps> = ({ onStartVoiceCall, onStartVideoCall }) => {
  const [message, setMessage] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const { addMessage, isTyping } = useChat();
  const inputRef = useRef<HTMLInputElement>(null);

  // Focus input on component mount
  useEffect(() => {
    if (inputRef.current) {
      inputRef.current.focus();
    }
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (message.trim()) {
      addMessage(message.trim(), 'user');
      setMessage('');
    }
  };

  const toggleRecording = () => {
    setIsRecording(!isRecording);
    
    // Simulate voice recognition
    if (!isRecording) {
      // Start recording animation
      setTimeout(() => {
        // Generate a simulated voice message
        const voiceMessages = [
          "I'm feeling a bit anxious today",
          "Can you help me with some relaxation techniques?",
          "I've been having trouble sleeping lately"
        ];
        const randomMessage = voiceMessages[Math.floor(Math.random() * voiceMessages.length)];
        
        setMessage(randomMessage);
        setIsRecording(false);
      }, 3000);
    }
  };

  return (
    <div className="border-t border-gray-200 bg-white p-4">
      <form onSubmit={handleSubmit} className="flex items-center gap-2">
        <div className="flex-1 relative">
          <input
            ref={inputRef}
            type="text"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder={isTyping ? "MindMate is typing..." : "Type your message..."}
            disabled={isTyping}
            className="w-full p-3 rounded-full border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 pr-10"
          />
          
          {isTyping && (
            <div className="absolute right-4 top-1/2 transform -translate-y-1/2">
              <motion.div className="flex space-x-1">
                <motion.div
                  className="w-2 h-2 bg-blue-500 rounded-full"
                  animate={{ y: [0, -6, 0] }}
                  transition={{ repeat: Infinity, duration: 0.8, delay: 0 }}
                />
                <motion.div
                  className="w-2 h-2 bg-blue-500 rounded-full"
                  animate={{ y: [0, -6, 0] }}
                  transition={{ repeat: Infinity, duration: 0.8, delay: 0.2 }}
                />
                <motion.div
                  className="w-2 h-2 bg-blue-500 rounded-full"
                  animate={{ y: [0, -6, 0] }}
                  transition={{ repeat: Infinity, duration: 0.8, delay: 0.4 }}
                />
              </motion.div>
            </div>
          )}
        </div>
        
        <motion.button
          type="button"
          onClick={toggleRecording}
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          className={`p-3 rounded-full ${isRecording ? 'bg-red-500' : 'bg-gray-200'}`}
          aria-label={isRecording ? "Stop recording" : "Start recording"}
        >
          {isRecording ? <MicOff size={20} className="text-white" /> : <Mic size={20} />}
        </motion.button>
        
        <motion.button
          type="button"
          onClick={onStartVoiceCall}
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          className="p-3 rounded-full bg-gray-200"
          aria-label="Start voice call"
        >
          <Phone size={20} />
        </motion.button>
        
        <motion.button
          type="button"
          onClick={onStartVideoCall}
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          className="p-3 rounded-full bg-gray-200"
          aria-label="Start video call"
        >
          <Video size={20} />
        </motion.button>
        
        <motion.button
          type="submit"
          disabled={!message.trim() || isTyping}
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          className={`p-3 rounded-full ${message.trim() && !isTyping ? 'bg-blue-500' : 'bg-gray-300'}`}
          aria-label="Send message"
        >
          <Send size={20} className={message.trim() && !isTyping ? 'text-white' : 'text-gray-500'} />
        </motion.button>
      </form>
    </div>
  );
};

export default ChatInput;