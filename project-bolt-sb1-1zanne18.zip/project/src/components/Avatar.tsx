import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { motion } from 'framer-motion';

interface AvatarProps {
  emotion?: 'neutral' | 'happy' | 'sad' | 'concerned' | 'encouraging';
  speaking?: boolean;
  size?: 'sm' | 'md' | 'lg';
}

const Avatar: React.FC<AvatarProps> = ({ 
  emotion = 'neutral', 
  speaking = false,
  size = 'md'
}) => {
  const { currentUser } = useAuth();
  const [blinkState, setBlinkState] = useState(false);
  
  // Determine avatar gender based on user gender (opposite)
  const avatarGender = currentUser?.gender === 'female' ? 'male' : 'female';
  
  // Set avatar image based on gender and emotion
  const getAvatarUrl = () => {
    // Using Unsplash for realistic human photos
    if (avatarGender === 'female') {
      switch(emotion) {
        case 'happy':
          return 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=400&h=400';
        case 'sad':
          return 'https://images.unsplash.com/photo-1597586124394-fbd6ef244026?auto=format&fit=crop&q=80&w=400&h=400';
        case 'concerned':
          return 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=400&h=400';
        case 'encouraging':
          return 'https://images.unsplash.com/photo-1601288496920-b6154fe3626a?auto=format&fit=crop&q=80&w=400&h=400';
        default:
          return 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=400&h=400';
      }
    } else {
      switch(emotion) {
        case 'happy':
          return 'https://images.unsplash.com/photo-1566492031773-4f4e44671857?auto=format&fit=crop&q=80&w=400&h=400';
        case 'sad':
          return 'https://images.unsplash.com/photo-1456327102063-fb5054efe647?auto=format&fit=crop&q=80&w=400&h=400';
        case 'concerned':
          return 'https://images.unsplash.com/photo-1552374196-c4e7ffc6e126?auto=format&fit=crop&q=80&w=400&h=400';
        case 'encouraging':
          return 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=400&h=400';
        default:
          return 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=400&h=400';
      }
    }
  };

  // Random blinking effect
  useEffect(() => {
    const blinkInterval = setInterval(() => {
      setBlinkState(true);
      setTimeout(() => setBlinkState(false), 200);
    }, 3000 + Math.random() * 4000); // Random blink between 3-7 seconds
    
    return () => clearInterval(blinkInterval);
  }, []);

  // Size classes
  const sizeClasses = {
    sm: 'w-12 h-12',
    md: 'w-24 h-24',
    lg: 'w-64 h-64'
  };

  return (
    <div className="relative">
      <motion.div 
        className={`rounded-full overflow-hidden ${sizeClasses[size]} border-2 border-blue-400`}
        animate={{
          scale: speaking ? [1, 1.03, 1] : 1,
          opacity: blinkState ? 0.9 : 1
        }}
        transition={{
          scale: { repeat: speaking ? Infinity : 0, duration: 0.5 },
          opacity: { duration: 0.1 }
        }}
      >
        <img 
          src={getAvatarUrl()} 
          alt="AI Avatar" 
          className="w-full h-full object-cover"
        />
      </motion.div>
      
      {speaking && (
        <motion.div 
          className="absolute bottom-0 left-0 right-0 h-1 bg-blue-500 rounded-full"
          animate={{
            scaleX: [0.3, 1, 0.6, 0.9, 0.4],
            opacity: [0.6, 1, 0.8, 1, 0.7]
          }}
          transition={{
            repeat: Infinity,
            duration: 1.5,
            ease: "easeInOut"
          }}
        />
      )}
    </div>
  );
};

export default Avatar;