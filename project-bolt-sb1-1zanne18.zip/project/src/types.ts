export interface User {
  id: string;
  name: string;
  email: string;
  age: number;
  gender: 'male' | 'female' | 'other';
}

export interface Message {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: number;
  emotion?: 'neutral' | 'happy' | 'sad' | 'concerned' | 'encouraging';
}

export interface ChatHistory {
  userId: string;
  messages: Message[];
}

export interface Theme {
  id: string;
  name: string;
  bgColor: string;
  textColor: string;
  accentColor: string;
}